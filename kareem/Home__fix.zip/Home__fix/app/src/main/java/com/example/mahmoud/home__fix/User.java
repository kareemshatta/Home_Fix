package com.example.mahmoud.home__fix;

/**
 * Created by eslamelhoseiny on 11/15/17.
 */

public class User {
    private String id;
    private String name;
    private String dateOfBirth;

    private String email;
    private String city;
    private String area;
    private String phone_number;
    private String proffe;

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getProffe() {
        return proffe;
    }

    public void setProffe(String proffe) {
        this.proffe = proffe;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }



    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
